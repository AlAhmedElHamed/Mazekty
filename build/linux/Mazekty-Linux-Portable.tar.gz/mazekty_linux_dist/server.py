import os
import sys
import re
import time
import json
import uuid
import asyncio
import subprocess
import traceback
import tempfile
import urllib.request
import urllib.parse
from collections import defaultdict
from typing import List, Dict, Any, Optional
from contextlib import asynccontextmanager
from pydantic import BaseModel
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, BackgroundTasks, UploadFile, File, Form, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from downloader import YouTubeDownloader
from platform_utils import (
    get_config_path,
    get_cookies_path,
    get_user_data_dir,
    get_default_download_dir,
    open_folder_in_explorer,
    choose_folder_dialog,
    get_os_name,
    sync_to_system_music_library,
    get_local_ip,
    get_all_local_ips,
    detect_connected_ios_devices,
    detect_connected_android_devices,
    detect_all_connected_mobile_devices,
    sync_to_android_device,
    trigger_finder_ios_sync
)

@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    global main_event_loop, queue_worker_task, download_queue, queue_resume_event
    # Initialize asyncio objects inside the running loop
    download_queue = asyncio.Queue()
    queue_resume_event = asyncio.Event()
    queue_resume_event.set()
    main_event_loop = asyncio.get_running_loop()
    queue_worker_task = asyncio.create_task(queue_worker())
    asyncio.create_task(background_update_checker())
    yield
    if queue_worker_task:
        queue_worker_task.cancel()

app = FastAPI(title="مزيكتي - Mazekty", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

if getattr(sys, 'frozen', False):
    BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

STATIC_DIR = os.path.join(BASE_DIR, "static")
if not os.path.exists(STATIC_DIR) and getattr(sys, 'frozen', False):
    STATIC_DIR = os.path.join(os.path.dirname(sys.executable), "static")

CONFIG_FILE = get_config_path()

def sanitize_download_folder(folder_path: Optional[str]) -> str:
    default_dir = get_default_download_dir(BASE_DIR)
    if not folder_path or not str(folder_path).strip():
        return default_dir
    abs_path = os.path.abspath(str(folder_path).strip())
    # Prevent download folder from ever pointing into program files / app distribution
    bad_markers = ["_internal", "site-packages", "Mazekty.exe"]
    if any(m.lower() in abs_path.lower() for m in bad_markers) or os.path.isfile(os.path.join(abs_path, "Mazekty.exe")):
        return default_dir
    try:
        os.makedirs(abs_path, exist_ok=True)
    except Exception:
        return default_dir
    return abs_path

def load_config() -> Dict[str, Any]:
    default_dir = get_default_download_dir(BASE_DIR)
    cfg = {
        "download_folder": default_dir,
        "language": "ar",
        "is_pro": True,
        "theme_accent": "violet",
        "theme_mode": "dark",
        "os_name": get_os_name()
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                loaded = json.load(f)
                if isinstance(loaded, dict):
                    cfg.update(loaded)
        except Exception:
            pass
    cfg["download_folder"] = sanitize_download_folder(cfg.get("download_folder"))
    return cfg

def save_config(updates: Dict[str, Any]):
    cfg = load_config()
    if "download_folder" in updates:
        updates["download_folder"] = sanitize_download_folder(updates["download_folder"])
    cfg.update(updates)
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"Could not save config to {CONFIG_FILE}: {e}")
    return cfg

def validate_file_path(target_dir: str, filename: str) -> str:
    """Validates that filename resolves within target_dir, preventing path traversal."""
    resolved = os.path.realpath(os.path.join(target_dir, filename))
    if not resolved.startswith(os.path.realpath(target_dir) + os.sep) and resolved != os.path.realpath(target_dir):
        raise HTTPException(status_code=400, detail="Invalid file path")
    return resolved

class SimpleRateLimiter:
    """In-memory sliding window rate limiter for public-facing API endpoints."""
    def __init__(self, max_requests: int = 60, window_seconds: float = 60.0):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests: Dict[str, List[float]] = defaultdict(list)

    def is_allowed(self, client_ip: str) -> bool:
        now = time.time()
        cutoff = now - self.window_seconds
        timestamps = [t for t in self.requests[client_ip] if t > cutoff]
        if len(timestamps) >= self.max_requests:
            self.requests[client_ip] = timestamps
            return False
        timestamps.append(now)
        self.requests[client_ip] = timestamps
        return True

search_limiter = SimpleRateLimiter(max_requests=40, window_seconds=60.0)
download_limiter = SimpleRateLimiter(max_requests=60, window_seconds=60.0)
analyze_limiter = SimpleRateLimiter(max_requests=30, window_seconds=60.0)

initial_cfg = load_config()
DEFAULT_DOWNLOAD_DIR = os.path.abspath(initial_cfg.get("download_folder", get_default_download_dir(BASE_DIR)))
os.makedirs(DEFAULT_DOWNLOAD_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: Dict[str, Any]):
        for connection in list(self.active_connections):
            try:
                await connection.send_json(message)
            except Exception:
                self.disconnect(connection)

manager = ConnectionManager()

# Queue and State (initialized in lifespan to avoid asyncio issues on Python 3.12+)
download_queue: Optional[asyncio.Queue] = None
queue_worker_task: Optional[asyncio.Task] = None
main_event_loop: Optional[asyncio.AbstractEventLoop] = None

# Queue Pause / Cancel controls
is_queue_paused: bool = False
queue_resume_event: Optional[asyncio.Event] = None
cancelled_item_ids = set()

session_stats = {
    "total": 0,
    "completed": 0,
    "skipped": 0,
    "failed": 0,
    "in_progress": 0
}

all_items: Dict[str, Dict[str, Any]] = {}
downloader_instance = YouTubeDownloader(output_dir=DEFAULT_DOWNLOAD_DIR)

async def queue_worker():
    """Continuously processes items from the download queue with pause/cancel controls."""
    while True:
        # Check if queue is paused
        await queue_resume_event.wait()

        item = await download_queue.get()
        item_id = item["id"]
        target_folder = item.get("folder") or DEFAULT_DOWNLOAD_DIR

        # Check if cancelled before starting
        if item_id in cancelled_item_ids:
            item["status"] = "cancelled"
            session_stats["skipped"] += 1
            await manager.broadcast({
                "event": "item_cancelled",
                "item_id": item_id,
                "title": item["title"],
                "stats": session_stats
            })
            cancelled_item_ids.discard(item_id)
            download_queue.task_done()
            continue

        session_stats["in_progress"] += 1
        await manager.broadcast({
            "event": "stats_update",
            "stats": session_stats
        })

        # 1. Smart Skip Existing
        existing_file = downloader_instance.is_already_downloaded(item["title"], target_folder)
        if existing_file:
            item["status"] = "skipped"
            item["existing_file"] = existing_file
            session_stats["in_progress"] -= 1
            session_stats["skipped"] += 1

            await manager.broadcast({
                "event": "item_skipped",
                "item_id": item_id,
                "title": item["title"],
                "existing_file": existing_file,
                "stats": session_stats
            })
            download_queue.task_done()
            continue

        # 2. Download Item
        item["status"] = "downloading"
        await manager.broadcast({
            "event": "item_started",
            "item_id": item_id,
            "title": item["title"],
            "url": item["url"],
            "index": item.get("playlist_index"),
            "total": item.get("playlist_total"),
            "format": item.get("audio_format", "mp3"),
            "stats": session_stats
        })

        def progress_hook(d):
            status = d.get('status')
            if status == 'downloading':
                downloaded = d.get('downloaded_bytes', 0)
                total = d.get('total_bytes') or d.get('total_bytes_estimate') or 0
                if total and total > 0:
                    percent = round((downloaded / total) * 100, 1)
                else:
                    percent = -1  # Indeterminate stream or long fragmented video
                downloaded_mb = round(downloaded / (1024 * 1024), 1)
                total_mb = round(total / (1024 * 1024), 1) if total and total > 0 else 0
                speed = d.get('_speed_str', '')
                eta = d.get('_eta_str', '')
                info_dict = d.get('info_dict', {})
                title = info_dict.get('title') or item["title"]

                if main_event_loop and main_event_loop.is_running():
                    asyncio.run_coroutine_threadsafe(
                        manager.broadcast({
                            "event": "progress",
                            "item_id": item_id,
                            "percent": percent,
                            "downloaded_mb": downloaded_mb,
                            "total_mb": total_mb,
                            "speed": speed,
                            "eta": eta,
                            "title": title,
                            "status": "downloading"
                        }),
                        main_event_loop
                    )
            elif status == 'finished':
                if main_event_loop and main_event_loop.is_running():
                    asyncio.run_coroutine_threadsafe(
                        manager.broadcast({
                            "event": "progress",
                            "item_id": item_id,
                            "percent": 100,
                            "status": "converting",
                            "stage_text": "جاري تحويل ومعالجة الصوت (FFmpeg)...",
                            "title": item["title"]
                        }),
                        main_event_loop
                    )

        def postprocessor_hook(d):
            pp = d.get('postprocessor', '')
            status = d.get('status')
            if status == 'started':
                stage_text = "دمج صورة الغلاف والبيانات..." if ("Thumbnail" in pp or "Metadata" in pp) else "معالجة وتحسين الصوت..."
                if main_event_loop and main_event_loop.is_running():
                    asyncio.run_coroutine_threadsafe(
                        manager.broadcast({
                            "event": "progress",
                            "item_id": item_id,
                            "percent": 100,
                            "status": "processing",
                            "stage_text": stage_text,
                            "title": item["title"]
                        }),
                        main_event_loop
                    )

        try:
            loop = asyncio.get_running_loop()
            info = await loop.run_in_executor(
                None,
                lambda: downloader_instance.download_item(
                    url=item["url"],
                    quality=item.get("quality", "320"),
                    audio_format=item.get("audio_format", "mp3"),
                    embed_thumbnail=item.get("embed_thumbnail", True),
                    embed_metadata=item.get("embed_metadata", True),
                    rate_limit_kbps=item.get("rate_limit_kbps"),
                    custom_folder=target_folder,
                    progress_hook=progress_hook,
                    postprocessor_hook=postprocessor_hook
                )
            )

            final_title = info.get('title', item["title"]) if isinstance(info, dict) else item["title"]
            item["status"] = "completed"
            item["title"] = final_title
            session_stats["in_progress"] -= 1
            session_stats["completed"] += 1

            await manager.broadcast({
                "event": "item_completed",
                "item_id": item_id,
                "title": final_title,
                "stats": session_stats
            })
        except Exception as err:
            err_msg = str(err)
            traceback.print_exc()
            item["status"] = "error"
            item["error"] = err_msg
            session_stats["in_progress"] -= 1
            session_stats["failed"] += 1

            await manager.broadcast({
                "event": "item_error",
                "item_id": item_id,
                "title": item["title"],
                "error": err_msg,
                "stats": session_stats
            })
        finally:
            download_queue.task_done()
            if len(all_items) > 500:
                finished_keys = [k for k, v in list(all_items.items()) if v.get("status") in ("completed", "skipped", "cancelled", "error")]
                for k in finished_keys[:len(all_items) - 200]:
                    all_items.pop(k, None)

# ==========================================
# REQUEST MODELS
# ==========================================

class AnalyzeRequest(BaseModel):
    url: str

class DownloadRequest(BaseModel):
    urls: str
    quality: str = "320"
    audio_format: Optional[str] = "mp3"
    embed_thumbnail: bool = True
    embed_metadata: bool = True
    rate_limit_kbps: Optional[int] = None
    folder: Optional[str] = None
    selected_urls: Optional[List[str]] = None

class SearchRequest(BaseModel):
    query: str
    limit: Optional[int] = 12

class TrimRequest(BaseModel):
    filename: str
    start: float
    end: float
    is_ringtone: bool = False
    folder: Optional[str] = None

class EnhanceRequest(BaseModel):
    filename: str
    bass_boost: bool = True
    normalize: bool = True
    folder: Optional[str] = None

class VocalRemoveRequest(BaseModel):
    filename: str
    folder: Optional[str] = None

class PitchSpeedRequest(BaseModel):
    filename: str
    pitch: float = 0.0      # semitones (-6 to +6)
    speed: float = 1.0      # multiplier (0.5 to 2.0)
    folder: Optional[str] = None

class Spatial8DRequest(BaseModel):
    filename: str
    folder: Optional[str] = None

class EqualizerRequest(BaseModel):
    filename: str
    preset: str = "bass_boost"
    folder: Optional[str] = None
    custom_gains: Optional[Dict[str, float]] = None

class SilenceRemoveRequest(BaseModel):
    filename: str
    folder: Optional[str] = None

class VolumeBoostRequest(BaseModel):
    filename: str
    gain_db: float = 6.0
    folder: Optional[str] = None

class BatchConvertRequest(BaseModel):
    target_format: str = "mp3"
    bitrate: str = "320"
    folder: Optional[str] = None

class TagEditRequest(BaseModel):
    filename: str
    title: Optional[str] = None
    artist: Optional[str] = None
    album: Optional[str] = None
    year: Optional[str] = None
    genre: Optional[str] = None
    folder: Optional[str] = None

class SyncMusicRequest(BaseModel):
    filename: str
    playlist_name: Optional[str] = "Mazekty"
    folder: Optional[str] = None

class SyncAllRequest(BaseModel):
    folder: Optional[str] = None
    playlist_name: Optional[str] = "Mazekty"

class SyncAndroidRequest(BaseModel):
    device_id: Optional[str] = None
    playlist_name: Optional[str] = "Mazekty"
    folder: Optional[str] = None
    files: Optional[List[str]] = None

class OpenFolderRequest(BaseModel):
    folder: Optional[str] = None

class ScheduleDownloadRequest(BaseModel):
    download_request: DownloadRequest
    delay_seconds: int

class ConfigUpdateRequest(BaseModel):
    download_folder: Optional[str] = None
    language: Optional[str] = None
    theme_accent: Optional[str] = None
    theme_mode: Optional[str] = None

class RetrySingleRequest(BaseModel):
    item_id: str
    quality: Optional[str] = None
    audio_format: Optional[str] = None

class SaveLrcRequest(BaseModel):
    filename: str
    lyrics: str
    folder: Optional[str] = None

class MergeTracksRequest(BaseModel):
    filenames: List[str]
    crossfade: float = 4.0
    output_filename: Optional[str] = None
    folder: Optional[str] = None

class DenoiseRequest(BaseModel):
    filename: str
    folder: Optional[str] = None

class StemsRequest(BaseModel):
    filename: str
    folder: Optional[str] = None

class IdentifyRequest(BaseModel):
    filename: str
    folder: Optional[str] = None

# ==========================================
# QUEUE CONTROL ENDPOINTS (FREE FEATURE)
# ==========================================

@app.post("/api/queue/pause")
async def pause_queue():
    global is_queue_paused
    is_queue_paused = True
    queue_resume_event.clear()
    await manager.broadcast({"event": "queue_paused"})
    return {"status": "paused"}

@app.post("/api/queue/resume")
async def resume_queue():
    global is_queue_paused
    is_queue_paused = False
    queue_resume_event.set()
    await manager.broadcast({"event": "queue_resumed"})
    return {"status": "resumed"}

@app.post("/api/queue/cancel/{item_id}")
async def cancel_queue_item(item_id: str):
    cancelled_item_ids.add(item_id)
    if item_id in all_items:
        all_items[item_id]["status"] = "cancelled"
    await manager.broadcast({"event": "item_cancelled", "item_id": item_id})
    return {"status": "cancelled", "item_id": item_id}

@app.get("/api/queue/status")
async def get_queue_status():
    return {
        "is_paused": is_queue_paused,
        "queue_size": download_queue.qsize(),
        "stats": session_stats
    }

@app.post("/api/queue/reset-stats")
async def reset_queue_stats():
    global session_stats
    session_stats = {"total": 0, "completed": 0, "skipped": 0, "failed": 0, "in_progress": 0}
    all_items.clear()
    cancelled_item_ids.clear()
    await manager.broadcast({"event": "stats_reset", "stats": session_stats})
    return {"status": "reset"}

@app.post("/api/queue/clear-completed")
async def clear_completed_queue():
    to_remove = [k for k, v in list(all_items.items()) if v.get("status") in ("completed", "skipped", "cancelled", "error")]
    for k in to_remove:
        all_items.pop(k, None)
    await manager.broadcast({"event": "items_cleared", "cleared_ids": to_remove})
    return {"status": "cleared", "count": len(to_remove)}

@app.post("/api/queue/retry-failed")
async def retry_failed_downloads():
    global session_stats
    retried_items = []
    for item_id, item in list(all_items.items()):
        if item.get("status") == "error":
            item["status"] = "queued"
            item.pop("error", None)
            session_stats["failed"] = max(0, session_stats["failed"] - 1)
            await download_queue.put(item)
            retried_items.append(item)

    if retried_items:
        await manager.broadcast({
            "event": "items_queued",
            "items": retried_items,
            "stats": session_stats,
            "queue_size": download_queue.qsize()
        })
    return {"status": "retried", "count": len(retried_items)}

@app.post("/api/queue/retry-single")
async def retry_single_download(req: RetrySingleRequest):
    global session_stats
    if req.item_id not in all_items:
        raise HTTPException(status_code=404, detail="Item not found in queue")

    item = all_items[req.item_id]
    if item.get("status") == "error":
        session_stats["failed"] = max(0, session_stats["failed"] - 1)

    if req.quality:
        item["quality"] = req.quality
    if req.audio_format:
        item["audio_format"] = req.audio_format

    item["status"] = "queued"
    item.pop("error", None)
    cancelled_item_ids.discard(req.item_id)
    await download_queue.put(item)

    await manager.broadcast({
        "event": "items_queued",
        "items": [item],
        "stats": session_stats,
        "queue_size": download_queue.qsize()
    })
    return {"status": "retried", "item": item}

# ==========================================
# CONFIG & SYSTEM ENDPOINTS
# ==========================================

@app.get("/api/config")
async def get_config():
    cfg = load_config()
    cfg["os_name"] = get_os_name()
    return cfg

@app.post("/api/config")
async def update_config(req: ConfigUpdateRequest):
    updates = {}
    if req.download_folder:
        updates["download_folder"] = os.path.abspath(req.download_folder)
        os.makedirs(updates["download_folder"], exist_ok=True)
    if req.language:
        updates["language"] = req.language
    if req.theme_accent:
        updates["theme_accent"] = req.theme_accent
    if req.theme_mode:
        updates["theme_mode"] = req.theme_mode
    return save_config(updates)

@app.post("/api/select-folder")
async def select_folder():
    cfg = load_config()
    current_dir = cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    loop = asyncio.get_running_loop()
    chosen = await loop.run_in_executor(None, lambda: choose_folder_dialog(initial_dir=current_dir))
    if chosen:
        save_config({"download_folder": chosen})
        return {"folder": chosen}
    return {"folder": None}

@app.post("/api/open-folder")
async def open_folder(req: OpenFolderRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    os.makedirs(target_dir, exist_ok=True)
    success = open_folder_in_explorer(target_dir)
    return {"status": "opened" if success else "failed", "folder": target_dir}

# ==========================================
# FREE FEATURES: ID3 TAGS, M3U EXPORT, VOLUME
# ==========================================

@app.get("/api/tags")
async def get_tags_endpoint(filename: str, folder: Optional[str] = None):
    cfg = load_config()
    target_dir = os.path.abspath(folder) if folder and folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    file_path = os.path.join(target_dir, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    return YouTubeDownloader.get_audio_tags(file_path)

@app.post("/api/tags")
async def save_tags_endpoint(req: TagEditRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    file_path = os.path.join(target_dir, req.filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")

    tags = {k: v for k, v in req.model_dump().items() if k not in ["filename", "folder"] and v is not None}
    success = YouTubeDownloader.save_audio_tags(file_path, tags)
    if success:
        return {"status": "success", "tags": tags}
    raise HTTPException(status_code=500, detail="Could not save audio tags")

@app.post("/api/export-m3u")
async def export_m3u_endpoint(req: SyncAllRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    try:
        m3u_path = YouTubeDownloader.export_m3u_playlist(target_dir)
        return {"status": "success", "file": os.path.basename(m3u_path), "path": m3u_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/boost-volume")
async def boost_volume_endpoint(req: VolumeBoostRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    base, ext = os.path.splitext(req.filename)
    out_name = f"{base}_boosted{ext}"
    output_file = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.boost_volume(input_file, output_file, gain_db=req.gain_db)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ==========================================
# PRO STUDIO FEATURES
# ==========================================

@app.post("/api/vocal-remove")
async def vocal_remove_endpoint(req: VocalRemoveRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    base, _ = os.path.splitext(req.filename)
    out_name = f"{base}_karaoke_inst.mp3"
    output_file = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.remove_vocals(input_file, output_file)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/pitch-speed")
async def pitch_speed_endpoint(req: PitchSpeedRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    base, _ = os.path.splitext(req.filename)
    out_name = f"{base}_pitch_{req.pitch:+0.1f}_speed_{req.speed:.1f}x.mp3"
    output_file = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.change_pitch_and_speed(input_file, output_file, req.pitch, req.speed)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/spatial-8d")
async def spatial_8d_endpoint(req: Spatial8DRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    base, _ = os.path.splitext(req.filename)
    out_name = f"{base}_8D_spatial.mp3"
    output_file = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.spatial_8d(input_file, output_file)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/equalizer")
async def equalizer_endpoint(req: EqualizerRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    base, _ = os.path.splitext(req.filename)
    out_name = f"{base}_eq_{req.preset}.mp3"
    output_file = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.apply_equalizer(input_file, output_file, req.preset, req.custom_gains)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/remove-silence")
async def remove_silence_endpoint(req: SilenceRemoveRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    base, ext = os.path.splitext(req.filename)
    out_name = f"{base}_clean_silence{ext}"
    output_file = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.remove_silence(input_file, output_file)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/batch-convert")
async def batch_convert_endpoint(req: BatchConvertRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    loop = asyncio.get_running_loop()
    try:
        res = await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.batch_convert(target_dir, req.target_format, req.bitrate)
        )
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/replace-artwork")
async def replace_artwork_endpoint(
    filename: str = Form(...),
    folder: Optional[str] = Form(None),
    image: UploadFile = File(...)
):
    cfg = load_config()
    target_dir = os.path.abspath(folder) if folder and folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    audio_file = os.path.join(target_dir, filename)
    if not os.path.exists(audio_file):
        raise HTTPException(status_code=404, detail="Audio file not found")

    temp_img_path = os.path.join(target_dir, f"_temp_art_{uuid.uuid4().hex[:6]}.jpg")
    try:
        with open(temp_img_path, "wb") as f:
            f.write(await image.read())

        success = YouTubeDownloader.replace_artwork(audio_file, temp_img_path)
        if success:
            return {"status": "success", "filename": filename}
        raise HTTPException(status_code=500, detail="Could not replace album art")
    finally:
        if os.path.exists(temp_img_path):
            os.remove(temp_img_path)

@app.get("/api/lyrics")
async def get_lyrics_endpoint(title: Optional[str] = None, artist: Optional[str] = None, url: Optional[str] = None):
    loop = asyncio.get_running_loop()
    if title:
        res = await loop.run_in_executor(None, lambda: YouTubeDownloader.fetch_synced_lyrics(title, artist))
        if res.get("found"):
            return res
    if url:
        yt_res = await loop.run_in_executor(None, lambda: YouTubeDownloader.extract_lyrics(url))
        return yt_res
    return {"found": False, "error": "No lyrics found"}

@app.post("/api/lyrics/save-lrc")
async def save_lrc_endpoint(req: SaveLrcRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    file_path = os.path.join(target_dir, req.filename)
    loop = asyncio.get_running_loop()
    try:
        lrc_file = await loop.run_in_executor(None, lambda: YouTubeDownloader.save_lrc_file(file_path, req.lyrics))
        return {"status": "success", "file": os.path.basename(lrc_file)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/studio/merge")
async def merge_tracks_endpoint(req: MergeTracksRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    full_paths = [os.path.join(target_dir, f) for f in req.filenames]
    out_name = req.output_filename or f"Mazekty_DJ_Mix_{int(time.time())}.mp3"
    if not out_name.lower().endswith(".mp3"):
        out_name += ".mp3"
    out_path = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.merge_audio_tracks(full_paths, req.crossfade, out_path)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/studio/denoise")
async def denoise_endpoint(req: DenoiseRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    base, _ = os.path.splitext(req.filename)
    out_name = f"{base}_denoised.mp3"
    out_path = os.path.join(target_dir, out_name)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.denoise_audio(input_file, out_path)
        )
        return {"status": "success", "filename": out_name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/studio/stems")
async def stems_endpoint(req: StemsRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    loop = asyncio.get_running_loop()
    try:
        res = await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.separate_stems(input_file, target_dir)
        )
        return {"status": "success", "stems": res}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/studio/identify")
async def identify_endpoint(req: IdentifyRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)
    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="File not found")

    loop = asyncio.get_running_loop()
    try:
        res = await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.identify_audio(input_file)
        )
        return res
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ==========================================
# SCHEDULED DOWNLOAD TIMER (PRO FEATURE)
# ==========================================

async def run_delayed_download(delay_sec: int, req: DownloadRequest):
    await asyncio.sleep(delay_sec)
    await async_resolve_and_enqueue(
        urls_raw=req.urls,
        quality=req.quality,
        audio_format=req.audio_format or "mp3",
        embed_thumb=req.embed_thumbnail,
        embed_meta=req.embed_metadata,
        rate_limit_kbps=req.rate_limit_kbps,
        folder=req.folder or DEFAULT_DOWNLOAD_DIR,
        selected_urls=req.selected_urls
    )

@app.post("/api/schedule-download")
async def schedule_download_endpoint(req: ScheduleDownloadRequest):
    asyncio.create_task(run_delayed_download(req.delay_seconds, req.download_request))
    return {
        "status": "scheduled",
        "delay_seconds": req.delay_seconds,
        "message": f"تمت جدولة التحميل ليعمل بعد {req.delay_seconds // 60} دقيقة تلقائياً."
    }

# ==========================================
# SEARCH & TRIM & ENHANCE & SYNC
# ==========================================

@app.post("/api/search")
async def search_youtube_endpoint(req: SearchRequest, request: Request):
    client_ip = request.client.host if request.client else "127.0.0.1"
    if not search_limiter.is_allowed(client_ip):
        raise HTTPException(status_code=429, detail="Too many search requests. Please wait a moment.")
    query = req.query.strip()
    if not query:
        return {"results": []}

    loop = asyncio.get_running_loop()
    results = await loop.run_in_executor(
        None,
        lambda: downloader_instance.search_youtube(query=query, limit=req.limit or 12)
    )
    return {"results": results, "query": query}

@app.post("/api/trim")
async def trim_audio_endpoint(req: TrimRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)

    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="الملف غير موجود")

    base, _ = os.path.splitext(req.filename)
    out_filename = f"{base}_ringtone.m4r" if req.is_ringtone else f"{base}_trimmed.mp3"
    output_file = os.path.join(target_dir, out_filename)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.trim_audio(
                input_file=input_file,
                start_sec=req.start,
                end_sec=req.end,
                output_file=output_file,
                is_ringtone=req.is_ringtone
            )
        )
        return {"status": "success", "filename": out_filename, "folder": target_dir}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/enhance")
async def enhance_audio_endpoint(req: EnhanceRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    input_file = os.path.join(target_dir, req.filename)

    if not os.path.exists(input_file):
        raise HTTPException(status_code=404, detail="الملف غير موجود")

    base, _ = os.path.splitext(req.filename)
    out_filename = f"{base}_studio_enhanced.mp3"
    output_file = os.path.join(target_dir, out_filename)

    loop = asyncio.get_running_loop()
    try:
        await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.enhance_audio(
                input_file=input_file,
                output_file=output_file,
                bass_boost=req.bass_boost,
                normalize=req.normalize
            )
        )
        return {"status": "success", "filename": out_filename, "folder": target_dir}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/sync-music")
async def sync_music_endpoint(req: SyncMusicRequest):
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    file_path = os.path.join(target_dir, req.filename)

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="الملف غير موجود")

    loop = asyncio.get_running_loop()
    res = await loop.run_in_executor(
        None,
        lambda: sync_to_system_music_library(file_path=file_path, playlist_name=req.playlist_name or "Mazekty")
    )

    if res.get("success"):
        return {"status": "success", "message": res.get("message"), "playlist": res.get("playlist")}
    else:
        raise HTTPException(status_code=500, detail=res.get("message", "تعذر ربط الملف مع مشغل الموسيقى."))

@app.post("/api/sync-all-music")
async def sync_all_music_endpoint(req: SyncAllRequest):
    """Batch import all audio files in the folder to System / Apple Music under a playlist."""
    cfg = load_config()
    target_dir = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)

    loop = asyncio.get_running_loop()
    res = await loop.run_in_executor(
        None,
        lambda: YouTubeDownloader.sync_all_to_apple_music(folder_path=target_dir, playlist_name=req.playlist_name or "Mazekty")
    )
    return res

# ==========================================
# MOBILE & IPHONE SYNC ENDPOINTS
# ==========================================

@app.get("/mobile")
async def get_mobile_page():
    """Serves the mobile web player and downloader optimized for iOS Safari."""
    mobile_html_path = os.path.join(STATIC_DIR, "mobile.html")
    if os.path.exists(mobile_html_path):
        return FileResponse(mobile_html_path, media_type="text/html")
    raise HTTPException(status_code=404, detail="Mobile page not found")

@app.get("/api/mobile/info")
async def get_mobile_info(request: Request, ip: Optional[str] = None):
    """Returns local network URL for QR Code and iPhone connectivity."""
    all_ips = get_all_local_ips()
    primary_ip = ip if (ip and ip in all_ips) else get_local_ip()
    port = request.url.port or 8000
    return {
        "local_ip": primary_ip,
        "available_ips": all_ips,
        "port": port,
        "mobile_url": f"http://{primary_ip}:{port}/mobile"
    }

@app.get("/api/mobile/download-zip")
async def download_mobile_zip(folder: Optional[str] = None):
    """Packages all audio files into a single ZIP for instant iPhone Files app download."""
    cfg = load_config()
    target_dir = os.path.abspath(folder) if folder and folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    loop = asyncio.get_running_loop()
    try:
        zip_path = await loop.run_in_executor(
            None,
            lambda: YouTubeDownloader.create_playlist_zip(target_dir)
        )
        return FileResponse(zip_path, media_type="application/zip", filename="Mazekty_Playlist_Mobile.zip")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/sync/devices")
async def get_connected_devices():
    """Detects both iOS (iPhone/iPad) and Android mobile devices connected via USB."""
    loop = asyncio.get_running_loop()
    devices = await loop.run_in_executor(None, detect_all_connected_mobile_devices)
    ios_count = sum(1 for d in devices if d.get("platform") == "ios")
    android_count = sum(1 for d in devices if d.get("platform") == "android")
    return {
        "devices": devices,
        "count": len(devices),
        "ios_count": ios_count,
        "android_count": android_count
    }

@app.post("/api/sync/trigger-ios")
async def trigger_ios_sync_endpoint():
    """Triggers Finder sync for connected iOS devices on macOS."""
    loop = asyncio.get_running_loop()
    res = await loop.run_in_executor(None, trigger_finder_ios_sync)
    return res

@app.post("/api/sync/trigger-android")
async def trigger_android_sync_endpoint(req: Optional[SyncAndroidRequest] = None):
    """Syncs songs directly to connected Android device via ADB."""
    loop = asyncio.get_running_loop()
    dev_id = req.device_id if req else None
    playlist = req.playlist_name if (req and req.playlist_name) else "Mazekty"
    target_folder = (req.folder if req and req.folder else None) or DEFAULT_DOWNLOAD_DIR

    file_list = None
    if req and req.files:
        file_list = [os.path.join(target_folder, f) if not os.path.isabs(f) else f for f in req.files]
    else:
        if os.path.exists(target_folder):
            file_list = [
                os.path.join(target_folder, f) for f in os.listdir(target_folder)
                if f.lower().endswith(('.mp3', '.m4a', '.flac', '.wav', '.mp4'))
            ]

    res = await loop.run_in_executor(None, lambda: sync_to_android_device(dev_id, file_list, playlist))
    return res

@app.post("/api/analyze")
async def analyze_url(req: AnalyzeRequest, request: Request):
    client_ip = request.client.host if request.client else "127.0.0.1"
    if not analyze_limiter.is_allowed(client_ip):
        raise HTTPException(status_code=429, detail="Too many analyze requests. Please wait a moment.")
    urls = YouTubeDownloader.clean_urls(req.url)
    if not urls:
        raise HTTPException(status_code=400, detail="لم يتم العثور على روابط صالحة")

    downloader = YouTubeDownloader()
    results = []
    loop = asyncio.get_running_loop()

    for u in urls[:10]:
        try:
            info = await loop.run_in_executor(None, downloader.get_info, u)
            results.append({"url": u, "status": "success", "data": info})
        except Exception as e:
            results.append({"url": u, "status": "error", "message": str(e)})

    return {"results": results, "total": len(urls)}

async def async_resolve_and_enqueue(
    urls_raw: str,
    quality: str,
    audio_format: str,
    embed_thumb: bool,
    embed_meta: bool,
    folder: str,
    rate_limit_kbps: Optional[int] = None,
    selected_urls: Optional[List[str]] = None
):
    loop = asyncio.get_running_loop()
    resolved_items = await loop.run_in_executor(
        None,
        downloader_instance.resolve_urls,
        urls_raw
    )

    new_items_list = []
    for entry in resolved_items:
        # Filter if selected_urls provided
        if selected_urls and entry["url"] not in selected_urls:
            continue

        item_id = f"item_{uuid.uuid4().hex[:8]}"
        item_data = {
            "id": item_id,
            "url": entry["url"],
            "title": entry.get("title") or "فيديو يوتيوب",
            "quality": quality,
            "audio_format": audio_format,
            "embed_thumbnail": embed_thumb,
            "embed_metadata": embed_meta,
            "rate_limit_kbps": rate_limit_kbps,
            "folder": folder,
            "playlist_index": entry.get("playlist_index"),
            "playlist_total": entry.get("playlist_total"),
            "playlist_title": entry.get("playlist_title"),
            "status": "queued"
        }
        all_items[item_id] = item_data
        new_items_list.append(item_data)
        session_stats["total"] += 1
        await download_queue.put(item_data)

    await manager.broadcast({
        "event": "items_queued",
        "items": new_items_list,
        "stats": session_stats,
        "queue_size": download_queue.qsize()
    })

@app.post("/api/download")
async def start_download(req: DownloadRequest, request: Request):
    client_ip = request.client.host if request.client else "127.0.0.1"
    if not download_limiter.is_allowed(client_ip):
        raise HTTPException(status_code=429, detail="Too many download requests. Please wait a moment.")
    urls = YouTubeDownloader.clean_urls(req.urls)
    if not urls:
        raise HTTPException(status_code=400, detail="يرجى إدخال رابط يوتيوب واحد على الأقل")

    cfg = load_config()
    target_folder = os.path.abspath(req.folder) if req.folder and req.folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    os.makedirs(target_folder, exist_ok=True)

    save_config({"download_folder": target_folder})

    asyncio.create_task(
        async_resolve_and_enqueue(
            urls_raw=req.urls,
            quality=req.quality,
            audio_format=req.audio_format or "mp3",
            embed_thumb=req.embed_thumbnail,
            embed_meta=req.embed_metadata,
            folder=target_folder,
            rate_limit_kbps=req.rate_limit_kbps,
            selected_urls=req.selected_urls
        )
    )

    return {
        "status": "processing_urls",
        "message": "جاري فك الروابط وإضافتها إلى الطابور فوراً...",
        "target_folder": target_folder
    }

@app.get("/api/downloads")
async def list_downloads(folder: Optional[str] = None):
    cfg = load_config()
    target_dir = os.path.abspath(folder) if folder and folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    if not os.path.exists(target_dir):
        return {"files": [], "folder": target_dir}

    files = []
    valid_exts = (".mp3", ".m4a", ".flac", ".wav", ".m4r", ".mp4", ".aac")
    try:
        for entry in os.scandir(target_dir):
            if entry.is_file() and entry.name.lower().endswith(valid_exts):
                stat = entry.stat()
                size_mb = round(stat.st_size / (1024 * 1024), 2)
                files.append({
                    "name": entry.name,
                    "size_mb": size_mb,
                    "modified": stat.st_mtime,
                    "is_video": entry.name.lower().endswith(".mp4"),
                    "is_ringtone": entry.name.lower().endswith(".m4r")
                })
        files.sort(key=lambda x: x["modified"], reverse=True)
    except Exception as e:
        return {"files": [], "folder": target_dir, "error": str(e)}

    return {"files": files, "folder": target_dir}

@app.get("/api/audio/{filename}")
async def get_audio_file(filename: str, folder: Optional[str] = None):
    cfg = load_config()
    target_dir = os.path.abspath(folder) if folder and folder.strip() else cfg.get("download_folder", DEFAULT_DOWNLOAD_DIR)
    file_path = validate_file_path(target_dir, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="الملف غير موجود")
    
    media_type = "audio/mpeg"
    if filename.lower().endswith((".m4a", ".m4r")):
        media_type = "audio/mp4"
    elif filename.lower().endswith(".wav"):
        media_type = "audio/wav"
    elif filename.lower().endswith(".flac"):
        media_type = "audio/flac"
    elif filename.lower().endswith(".mp4"):
        media_type = "video/mp4"

    return FileResponse(file_path, media_type=media_type, filename=filename)

# ==========================================
# COOKIES MANAGEMENT (BYPASS YOUTUBE BOT CHALLENGE)
# ==========================================

@app.get("/api/cookies/status")
async def get_cookies_status_api():
    cookie_file = get_cookies_path()
    has_cookies = os.path.isfile(cookie_file) and os.path.getsize(cookie_file) > 10
    size = os.path.getsize(cookie_file) if has_cookies else 0
    return {
        "enabled": has_cookies,
        "size_bytes": size,
        "size_kb": round(size / 1024, 1),
        "path": cookie_file
    }

@app.post("/api/cookies/upload")
async def upload_cookies_api(file: Optional[UploadFile] = File(None), raw_text: Optional[str] = Form(None)):
    cookie_file = get_cookies_path()
    content = ""
    if file:
        content_bytes = await file.read()
        content = content_bytes.decode("utf-8", errors="ignore")
    elif raw_text:
        content = raw_text

    if not content or not content.strip():
        raise HTTPException(status_code=400, detail="محتوى الكوكيز فارغ")

    try:
        with open(cookie_file, "w", encoding="utf-8") as f:
            f.write(content.strip() + "\n")
        return {
            "success": True,
            "message": "تم حفظ الكوكيز بنجاح وتفعيلها لجميع التحميلات!",
            "size_kb": round(len(content) / 1024, 1)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"تعذر حفظ الكوكيز: {e}")

@app.post("/api/cookies/delete")
async def delete_cookies_api():
    cookie_file = get_cookies_path()
    if os.path.exists(cookie_file):
        try:
            os.remove(cookie_file)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"تعذر حذف الكوكيز: {e}")
    return {"success": True, "message": "تم حذف الكوكيز بنجاح"}


# ==========================================
# AUTO-UPDATE ENGINE (GITHUB RELEASES)
# ==========================================

APP_VERSION = "1.5.4"
GITHUB_REPO = "AlAhmedElHamed/Mazekty"
GITHUB_RELEASES_API = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"

update_state: Dict[str, Any] = {
    "status": "idle",
    "percent": 0.0,
    "downloaded_mb": 0.0,
    "total_mb": 0.0,
    "speed": "",
    "eta": "",
    "latest_version": "",
    "release_title": "",
    "release_notes": "",
    "asset_name": "",
    "asset_size": 0,
    "download_url": "",
    "installer_path": "",
    "error": None
}

def parse_semver(v: str) -> tuple:
    cleaned = re.sub(r'^[vV]', '', str(v).strip())
    parts = []
    for p in re.split(r'[.-]', cleaned):
        if p.isdigit():
            parts.append(int(p))
    return tuple(parts)

def fetch_latest_github_release() -> Optional[Dict[str, Any]]:
    try:
        req = urllib.request.Request(
            GITHUB_RELEASES_API,
            headers={
                "User-Agent": f"Mazekty-Pro/{APP_VERSION}",
                "Accept": "application/vnd.github.v3+json"
            }
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data
    except Exception as err:
        print(f"Error checking GitHub releases: {err}")
        return None

def find_platform_asset(assets: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    os_name = get_os_name().lower()
    if "windows" in os_name or "win" in os_name:
        for a in assets:
            if a.get("name") == "Mazekty_Windows_Setup.exe":
                return a
        for a in assets:
            if a.get("name", "").endswith(".exe"):
                return a
        for a in assets:
            if a.get("name") == "Mazekty-Windows-Portable.zip":
                return a
    elif "mac" in os_name or "darwin" in os_name:
        for a in assets:
            if a.get("name", "").endswith(".dmg"):
                return a
    elif "linux" in os_name:
        for a in assets:
            if a.get("name", "").endswith(".tar.gz"):
                return a
    return assets[0] if assets else None

@app.get("/api/update/check")
async def check_update_api():
    loop = asyncio.get_running_loop()
    release_data = await loop.run_in_executor(None, fetch_latest_github_release)
    if not release_data:
        return {
            "update_available": False,
            "current_version": APP_VERSION,
            "message": "تعذر التحقق من التحديثات عبر GitHub حالياً"
        }

    tag_name = release_data.get("tag_name", "").lstrip("vV")
    latest_version = tag_name
    curr_v = parse_semver(APP_VERSION)
    latest_v = parse_semver(latest_version)

    is_newer = (latest_v > curr_v)
    asset = find_platform_asset(release_data.get("assets", []))

    result = {
        "update_available": is_newer,
        "current_version": APP_VERSION,
        "latest_version": latest_version,
        "release_title": release_data.get("name") or f"Mazekty Pro v{latest_version}",
        "release_notes": release_data.get("body") or "",
        "published_at": release_data.get("published_at"),
        "asset_name": asset.get("name") if asset else None,
        "asset_size": asset.get("size") if asset else 0,
        "download_url": asset.get("browser_download_url") if asset else None
    }

    if is_newer and asset:
        update_state.update({
            "status": "available",
            "latest_version": latest_version,
            "release_title": result["release_title"],
            "release_notes": result["release_notes"],
            "asset_name": asset.get("name"),
            "asset_size": asset.get("size"),
            "download_url": asset.get("browser_download_url")
        })

    return result

@app.post("/api/update/download")
async def download_update_api(background_tasks: BackgroundTasks):
    if update_state.get("status") == "downloading":
        return {"status": "downloading", "message": "جاري التحميل بالفعل"}

    if not update_state.get("download_url"):
        check_res = await check_update_api()
        if not check_res.get("download_url"):
            raise HTTPException(status_code=400, detail="لا يوجد ملف تحديث متاح للتنزيل")

    background_tasks.add_task(start_update_download_worker)
    return {"status": "started", "message": "بدأ تحميل التحديث في الخلفية"}

async def start_update_download_worker():
    download_url = update_state.get("download_url")
    asset_name = update_state.get("asset_name") or "Mazekty_Update.exe"

    update_dir = os.path.join(tempfile.gettempdir(), "Mazekty_Update")
    os.makedirs(update_dir, exist_ok=True)
    target_path = os.path.join(update_dir, asset_name)

    update_state["status"] = "downloading"
    update_state["percent"] = 0.0
    update_state["installer_path"] = target_path
    update_state["error"] = None

    try:
        loop = asyncio.get_running_loop()
        def _download():
            req = urllib.request.Request(download_url, headers={"User-Agent": f"Mazekty-Pro/{APP_VERSION}"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                total = int(resp.headers.get("content-length", 0))
                downloaded = 0
                start_t = time.time()
                last_time = 0

                with open(target_path, "wb") as f_out:
                    while True:
                        chunk = resp.read(64 * 1024)
                        if not chunk:
                            break
                        f_out.write(chunk)
                        downloaded += len(chunk)

                        now = time.time()
                        if now - last_time > 0.25:
                            last_time = now
                            elapsed = now - start_t
                            speed_bps = downloaded / elapsed if elapsed > 0 else 0
                            speed_str = f"{speed_bps / (1024 * 1024):.1f} MB/s" if speed_bps > 1024 * 1024 else f"{speed_bps / 1024:.0f} KB/s"
                            pct = round((downloaded / total * 100), 1) if total > 0 else 0
                            dl_mb = round(downloaded / (1024 * 1024), 1)
                            tot_mb = round(total / (1024 * 1024), 1)

                            update_state.update({
                                "percent": pct,
                                "downloaded_mb": dl_mb,
                                "total_mb": tot_mb,
                                "speed": speed_str
                            })

                            if main_event_loop and main_event_loop.is_running():
                                asyncio.run_coroutine_threadsafe(
                                    manager.broadcast({
                                        "event": "update_progress",
                                        "percent": pct,
                                        "downloaded_mb": dl_mb,
                                        "total_mb": tot_mb,
                                        "speed": speed_str
                                    }),
                                    main_event_loop
                                )
                return target_path

        final_file = await loop.run_in_executor(None, _download)
        update_state["status"] = "downloaded"
        update_state["percent"] = 100.0
        update_state["installer_path"] = final_file

        await manager.broadcast({
            "event": "update_downloaded",
            "installer_path": final_file,
            "latest_version": update_state.get("latest_version")
        })
    except Exception as e:
        update_state["status"] = "error"
        update_state["error"] = str(e)
        await manager.broadcast({
            "event": "update_error",
            "error": str(e)
        })

update_apply_lock = asyncio.Lock()

@app.post("/api/update/apply")
async def apply_update_api():
    async with update_apply_lock:
        if update_state.get("applying"):
            return {"status": "restarting", "message": "جاري تثبيت التحديث بالفعل..."}

        installer = update_state.get("installer_path")
        if not installer or not os.path.isfile(installer):
            raise HTTPException(status_code=400, detail="ملف التحديث غير موجود، يرجى التنزيل أولاً")

        update_state["applying"] = True

        os_name = get_os_name().lower()
        if "windows" in os_name or "win" in os_name:
            runner_dir = os.path.join(tempfile.gettempdir(), "Mazekty_Update")
            os.makedirs(runner_dir, exist_ok=True)
            lock_dir = os.path.join(runner_dir, "install_lock")
            runner_cmd = os.path.join(runner_dir, "apply_update.cmd")
            current_exe = os.path.abspath(sys.executable) if getattr(sys, 'frozen', False) else ""
            
            if installer.lower().endswith(".zip"):
                app_dir = os.path.dirname(current_exe) if current_exe else os.path.abspath(".")
                extracted_dir = os.path.join(runner_dir, "extracted")
                cmd_script = f"""@echo off
setlocal
mkdir "{lock_dir}" 2>nul || exit
timeout /t 2 /nobreak >nul 2>&1
taskkill /F /IM Mazekty.exe >nul 2>&1
timeout /t 1 /nobreak >nul 2>&1
powershell -Command "Expand-Archive -Path '{installer}' -DestinationPath '{extracted_dir}' -Force"
xcopy /E /Y /I "{extracted_dir}\\Mazekty\\*" "{app_dir}"
timeout /t 2 /nobreak >nul 2>&1
rmdir "{lock_dir}" 2>nul
if exist "{current_exe}" (
    start "" "{current_exe}"
)
exit
"""
            else:
                cmd_script = f"""@echo off
setlocal
mkdir "{lock_dir}" 2>nul || exit
timeout /t 2 /nobreak >nul 2>&1
taskkill /F /IM Mazekty.exe >nul 2>&1
timeout /t 1 /nobreak >nul 2>&1
start /wait "" "{installer}" /SILENT /VERYSILENT /SP- /SUPPRESSMSGBOXES /NORESTART /CLOSEAPPLICATIONS
timeout /t 2 /nobreak >nul 2>&1
rmdir "{lock_dir}" 2>nul
if exist "{current_exe}" (
    start "" "{current_exe}"
) else if exist "%LOCALAPPDATA%\\Programs\\Mazekty\\Mazekty.exe" (
    start "" "%LOCALAPPDATA%\\Programs\\Mazekty\\Mazekty.exe"
) else if exist "%ProgramFiles%\\Mazekty\\Mazekty.exe" (
    start "" "%ProgramFiles%\\Mazekty\\Mazekty.exe"
) else if exist "%ProgramFiles(x86)%\\Mazekty\\Mazekty.exe" (
    start "" "%ProgramFiles(x86)%\\Mazekty\\Mazekty.exe"
)
exit
"""
            with open(runner_cmd, "w", encoding="utf-8") as f:
                f.write(cmd_script)

            # CREATE_NO_WINDOW (0x08000000) prevents black cmd popups
            flags = 0x08000000 | getattr(subprocess, "DETACHED_PROCESS", 0x00000008) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0x00000200)
            subprocess.Popen(
                f'cmd.exe /c "{runner_cmd}"',
                shell=True,
                creationflags=flags
            )
        elif "mac" in os_name or "darwin" in os_name:
            subprocess.Popen(["open", installer])
        elif "linux" in os_name:
            pass

        asyncio.get_running_loop().call_later(0.8, lambda: os._exit(0))
        return {"status": "restarting", "message": "جاري تثبيت التحديث وإعادة تشغيل مزيكتي برو..."}

async def background_update_checker():
    await asyncio.sleep(2.0)
    try:
        res = await check_update_api()
        if res.get("update_available") and main_event_loop and main_event_loop.is_running():
            await manager.broadcast({
                "event": "update_available",
                "current_version": res.get("current_version"),
                "latest_version": res.get("latest_version"),
                "release_title": res.get("release_title"),
                "release_notes": res.get("release_notes"),
                "asset_name": res.get("asset_name"),
                "asset_size": res.get("asset_size"),
                "download_url": res.get("download_url")
            })
    except Exception:
        pass

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        cfg = load_config()
        cfg["os_name"] = get_os_name()
        await websocket.send_json({
            "event": "init_state",
            "stats": session_stats,
            "queue_size": download_queue.qsize(),
            "is_paused": is_queue_paused,
            "config": cfg,
            "items": list(all_items.values())[-50:]
        })
        while True:
            data = await websocket.receive_text()
            if not data:
                continue
            if data == "ping":
                await websocket.send_text("pong")
                continue

            # Process structured JSON WebSocket messages
            try:
                msg = json.loads(data)
                action = msg.get("action")
                if action == "ping":
                    await websocket.send_json({"event": "pong"})
                elif action == "get_state":
                    current_cfg = load_config()
                    current_cfg["os_name"] = get_os_name()
                    await websocket.send_json({
                        "event": "state_snapshot",
                        "stats": session_stats,
                        "queue_size": download_queue.qsize() if download_queue else 0,
                        "is_paused": is_queue_paused,
                        "config": current_cfg,
                        "items": list(all_items.values())[-50:]
                    })
                elif action == "get_stats":
                    await websocket.send_json({
                        "event": "stats_update",
                        "stats": session_stats
                    })
                elif action == "check_update":
                    up_info = await check_update_api()
                    await websocket.send_json({
                        "event": "update_check_result",
                        "data": up_info
                    })
                else:
                    await websocket.send_json({
                        "event": "error",
                        "message": f"Unsupported action: {action}"
                    })
            except json.JSONDecodeError:
                await websocket.send_json({
                    "event": "error",
                    "message": "Malformed message format, expected valid JSON or 'ping'"
                })
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception:
        manager.disconnect(websocket)

app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
